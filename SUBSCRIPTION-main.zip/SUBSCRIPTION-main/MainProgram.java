import java.sql.Connection;
import java.util.Scanner;

public class MainProgram {

    public static void main(String[] args) {

        Connection con = DBConnection.getConnection();
        if (con == null) {
            System.out.println("Database not connected!");
            return;
        }

        NetflixManagement nm = new NetflixManagement(con);
        Scanner sc = new Scanner(System.in);

        try {
            System.out.println("===== NETFLIX LOGIN =====");
            System.out.print("Enter User ID: ");
            int id = sc.nextInt();
            System.out.print("Enter Password: ");
            String pwd = sc.next();

            if (!nm.login(id, pwd)) {
                System.out.println("Invalid Login!");
                return;
            }

            System.out.println("Login Successful!");

            while (true) {
                System.out.println("\n---- MENU ----");
                System.out.println("1. Show Subscription");
                System.out.println("2. Subscribe to a Plan");
                System.out.println("3. Logout");
                System.out.print("Choose: ");
                int op = sc.nextInt();

                if (op == 1) {
                    nm.showDetails(id);
                }
                else if (op == 2) {
                    System.out.println("Choose Plan:");
                    System.out.println("1. Basic (₹199)");
                    System.out.println("2. Standard (₹499)");
                    System.out.println("3. Premium (₹799)");
                    int p = sc.nextInt();

                    String plan = "";
                    if (p == 1) plan = "Basic";
                    else if (p == 2) plan = "Standard";
                    else if (p == 3) plan = "Premium";

                    nm.subscribe(id, plan);
                }
                else if (op == 3) {
                    System.out.println("Logged Out.");
                    break;
                }
                else {
                    System.out.println("Invalid Option!");
                }
            }
        }

        finally {
            sc.close();
        }
    }
}
