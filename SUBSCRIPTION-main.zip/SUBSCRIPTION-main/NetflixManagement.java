import java.sql.*;

public class NetflixManagement {

    Connection con;

    public NetflixManagement(Connection con) {
        this.con = con;
    }

    // LOGIN METHOD
    public boolean login(int id, String pass) {
        try {
            String sql = "SELECT * FROM users WHERE userid=? AND password=?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, id);
            ps.setString(2, pass);

            ResultSet rs = ps.executeQuery();
            return rs.next();

        } catch (Exception e) {
            System.out.println(e);
            return false;
        }
    }

    // MAKE SUBSCRIPTION
    public void subscribe(int id, String plan) {

        double amount = 0;
        if (plan.equalsIgnoreCase("Basic")) amount = 199;
        else if (plan.equalsIgnoreCase("Standard")) amount = 499;
        else if (plan.equalsIgnoreCase("Premium")) amount = 799;

        try {
            String sql = "UPDATE users SET plan=?, amount=? WHERE userid=?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, plan);
            ps.setDouble(2, amount);
            ps.setInt(3, id);

            ps.executeUpdate();

            printReceipt(id, plan, amount);

        } catch (Exception e) {
            System.out.println(e);
        }
    }

    // PRINT DETAILS
    public void printReceipt(int id, String plan, double amount) {
        System.out.println("\n===== NETFLIX SUBSCRIPTION RECEIPT =====");
        System.out.println("User ID : " + id);
        System.out.println("Plan    : " + plan);
        System.out.println("Amount  : ₹" + amount);
        System.out.println("Status  : Activated");
        System.out.println("========================================\n");
    }

    // SHOW DETAILS
    public void showDetails(int id) {
        try {
            String sql = "SELECT * FROM users WHERE userid=?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, id);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                System.out.println("\n----- ACCOUNT DETAILS -----");
                System.out.println("User ID : " + rs.getInt("userid"));
                System.out.println("Name    : " + rs.getString("username"));
                System.out.println("Plan    : " + rs.getString("plan"));
                System.out.println("Amount  : ₹" + rs.getDouble("amount"));
                System.out.println("----------------------------\n");
            }

        } catch (Exception e) {
            System.out.println(e);
        }
    }
}
